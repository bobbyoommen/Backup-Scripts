python clone_groupsnap.py -C sf.json -l 14,15 -i 2 -n 1 -I 2 -M CL
