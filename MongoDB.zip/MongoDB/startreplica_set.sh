ssh mongo-rep1 "./startmongo.sh"
sleep 10
ssh mongo-rep2 "./startmongo.sh"
sleep 10
ssh mongo-rep3 "./startmongo.sh"
