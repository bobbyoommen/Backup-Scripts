#used to stop Mongo, deactivate LVM for each replica. You will need to do the same for all replicas.
ssh mongo-rep1 "pkill mongod"
sleep 10
ssh mongo-rep1 "umount /data/db"
ssh mongo-rep1 "vgchange -a n mongovg"
