#!/bin/ksh
#Change volumeids/accountids to match your setup
 
echo "Starting Consistent Group Snapshot on the Storage"
#--
python createSnap.py -C sf.json -l 14,15,16,17,18,19 -i 2 -S $1
echo "Consistent Group Snapshot creation Done"
