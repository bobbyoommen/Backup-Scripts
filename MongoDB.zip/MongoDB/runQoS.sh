perl set_QoS.py -C sf.json -l 1,2,3,4,5,6,7,13,14,15,16,17,18,19,20,21,22,23,24,25,26 -q default
