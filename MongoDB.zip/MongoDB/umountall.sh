#used as a wrapper to deactivate LVM using a ssh keyring setup
ssh mongo-rep1 "./umount.sh"
ssh mongo-rep2 "./umount.sh"
ssh mongo-rep3 "./umount.sh"
