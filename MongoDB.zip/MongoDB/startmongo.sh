echo "never" > /sys/kernel/mm/transparent_hugepage/enabled
echo "never" > /sys/kernel/mm/transparent_hugepage/defrag
/usr/bin/numactl  --interleave=all mongod -f /etc/mongod.conf
