#used as a wrapper to activate LVM using a ssh keyring setup

ssh mongo-rep1 "vgchange -a y mongovg"
ssh mongo-rep1 "mount -t xfs -o nobarrier,discard,noatime /dev/mongovg/mongolv /data/db/"

ssh mongo-rep2 "vgchange -a y mongovg"
ssh mongo-rep2 "mount -t xfs -o nobarrier,discard,noatime /dev/mongovg/mongolv /data/db/"

ssh mongo-rep3 "vgchange -a y mongovg"
ssh mongo-rep3 "mount -t xfs -o nobarrier,discard,noatime /dev/mongovg/mongolv /data/db/"

