#!/bin/ksh
#Change volumeids/accountids to match your setup
 
echo "Starting Recovery of Mongo Database"
python Recover.py -C sf.json -l 14,15,16,17,18,19 -G $1 
echo "End Recovery of Mongo Database"
