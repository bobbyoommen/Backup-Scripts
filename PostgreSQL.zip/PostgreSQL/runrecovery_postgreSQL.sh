#!/bin/ksh
#Change the volume id to match your setup
 
echo "Starting Recovery of PostgrSQL Database"
python Recover.py -C sf.json -l 182599 -G $1 
echo "End Recovery of PostgrSQL Database"
