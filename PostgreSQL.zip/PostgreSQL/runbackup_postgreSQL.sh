#!/bin/ksh
#Change volume id and sf.json file to match your setup
 
echo "Starting Consistent Group Snapshot on the Storage"
docker exec -it $1 /bin/bash -c "psql --u postgres postgres -f /pgdata/data/start_sf_backup.sql"
python createSnap.py -C sf.json -l 182599 -i 743 -S $2
docker exec -it $1 /bin/bash -c "psql --u postgres postgres -f /pgdata/data/end_sf_backup.sql"
python createSnap.py -C sf.json -l 182600 -i 743 -S $2
echo "Consistent Group Snapshot creation Done"
