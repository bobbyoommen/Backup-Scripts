#!/bin/ksh
# Change the volume ids and account ids to match your setup
 
echo "Starting Consistent Group Snapshot on the Storage"
python createSnap.py -C sf.json -l 179722,179723,179724,179725 -i 13 -S $1
python createSnap.py -C sf.json -l 179726 -i 13 -S $1
echo "Consistent Group Snapshot creation Done"
