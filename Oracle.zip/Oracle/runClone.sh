#Change volume ids and account ids to match your setup

python clone_groupsnap.py -C sf.json -l 179722,179723,179724,179725,179726 -i 13 -n 1 -I 1334 -M CL
