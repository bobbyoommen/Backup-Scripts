#!/bin/ksh
#Change the volume ids to match your setup
 
echo "Starting Recovery of ORADB"
python Recover.py -C sf.json -l 179722,179723,179724,179725 -G $1 
echo "End Recovery of ORADB"
