#!/usr/bin/python
# vim: tabstop=4 shiftwidth=4 softtabstop=4
# Copyright 2017 SolidFire Inc

import json
import logging
import re
import sf_exceptions
import sys
import time

from optparse import OptionParser
from SolidFireAPI import SolidFireAPI


def process_options():
    config = {}
    usage = "usage: %prog [options]"\
            "\n\nCreates n number of clones of specified volume(s)"
    parser = OptionParser(usage, version='%prog 1.1')

    parser.add_option('-V', '--verbose', action='store_true',
                      default=False,
                      dest='verbose',
                      help='Enable verbose messaging.')

    parser.add_option('-C', '--ClusterConfigFile', action='store',
                      type='string',
                      default=None,
                      dest='json_config',
                      help='JSON formatted cluster config, used'
                      ' to specify a SolidFire Cluster other than the default '
                      ' set up in the SolidFireAPI object')

    parser.add_option('-l', '--vidlist', action='store',
                      type='string',
                      default=None,
                      dest='vol_ids',
                      help='Comma seperated list of IDs to perform action on.'
                      ' ie: \"1,3,4,5,9\"',)

    parser.add_option('-i', '--accountid', action='store',
                      type='int',
                      default=-1,
                      dest='account_id',
                      help='Filter volumes by accountID '
                           '(omit for ALL active volumes).')

    parser.add_option('-n', '--clonespervolume', action='store',
                      type='int',
                      default=1,
                      dest='clones_per_volume',
                      help='Number of clones to create for each volume '
                           'omit for the default of 1.')

    parser.add_option('-N', '--no-waitasync', action='store_true',
                      default=False,
                      dest='no_asyncwait',
                      help='Do not wait for async operations '
                           'to complete before exiting. ')

    parser.add_option('-M', '--mart-name', action='store',
                      type='string',
                      default=None,
                      dest='mart_name',
                      help='Mart name associated with clone.'
                      ' ie: \"Mart-N\"',)

    parser.add_option('-I', '--target-accountid', action='store',
                      type='int',
                      default=0,
                      dest='target_account_id',
                      help='target account id '
                           'omit to use the source account id.')

    parser.add_option('-s', '--snapidlist', action='store',
                      type='string',
                      default=None,
                      dest='snap_ids',
                      help='Comma seperated list of snapshot IDs to perform action on.'
                      ' ie: \"1,3,4,5,9\"',)


    (options, args) = parser.parse_args()

    if options.verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    if options.json_config is not None:
        logging.info('Using provided json file for cluster info')
        config_text = open(options.json_config, 'r').read()
        config = json.loads(config_text)

    if config:
        cluster_object = SolidFireAPI(**config)
    else:
        cluster_object = SolidFireAPI()

    return (cluster_object, options)

if __name__ == "__main__":

    if len(sys.argv) == 1:
        sys.argv.append('-h')

    (SFC, options) = process_options()

    if options.account_id != -1:
        vol_list = SFC.get_volume_list_by_accountID(options.account_id)
    else:
        vol_list = SFC.get_volume_list()

    volid_list = []
    if options.vol_ids is not None:
        ids = re.findall(r'\w+', options.vol_ids)
        for i in ids:
            volid_list.append(int(i))

    volid_list = list(set(volid_list))

    async_handle_list = []
    vlist = []
    vol_names = {}
    for v in vol_list:
        if v['volumeID'] in volid_list:
            vol_names[v['volumeID']] = v['name']
            logging.debug('Volume:%s' % v)
    for vol in volid_list:
        id = vol
        clone_name = ("CL%s" % (vol_names[id] ))
        av = { 'volumeID' : id,
                   'name': clone_name }
        vlist.append(av)
    params = {'volumes': vlist }
    logging.info('Cloning volume:%s...' % volid_list)

    try:
        async_handle = SFC.issue_api_request('CloneMultipleVolumes', params, version='9.0')
        async_handle_list.append(async_handle)
    except:
        raise

    if not options.no_asyncwait:
        logging.info('waitasync was selected, wait for jobs to complete...')
        outstanding = True
        while outstanding:
            for h in async_handle_list:
                outstanding = False
                if 'asyncHandle' in h:
                    params = {'asyncHandle': h['asyncHandle']}
                    status = SFC.issue_api_request('GetAsyncResult', params)
                    if 'running' in status:
                        outstanding = True
                        time.sleep(1)
    else:
        logging.info('waitasync was NOT selected, exiting without checks...')
    logging.info('Succesfully cloned volumes %s.' % volid_list)








